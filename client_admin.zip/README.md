# fyAdmin
a fy admin based on [vuejs2].

### Usage

This is a project template for [vue-cli].

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8081
npm run dev

# build for production with minification
npm run build:dll
npm run build
```